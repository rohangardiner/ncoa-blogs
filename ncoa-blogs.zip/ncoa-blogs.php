<?php

/**
 * Plugin Name: NCOA Blogs
 * Description: Blog posting for NOCA networked sites
 * Version: 0.1.0
 * Author: Rohan
 */

// Create endppoint

// Create post

// Apply featured image